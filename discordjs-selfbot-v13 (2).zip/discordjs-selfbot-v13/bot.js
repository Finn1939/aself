const { Client } = require('./src/index');
const fs = require('fs').promises;
const path = require('path');

const client = new Client();
const STATE_FILE = path.join(__dirname, 'bot_state.json');

const channelConfigs = [
  { id: '1365731632534917141', interval: 610000 },
  { id: '1369721387987505203', interval: 61000 },
  { id: '1385899507572670555', interval: 61000 },
  { id: '1333096804589375549', interval: 31000 },
  { id: '1375650389671542995', interval: 121000 },
  { id: '1372798587611648000', interval: 181000 },
  { id: '1376864541744431144', interval: 301000 },
  { id: '1373272140526256229', interval: 450000 },
  { id: '1372546116930900080', interval: 240000 },

  // 🆕 Added channels
  { id: '1268315944141324369', interval: 31000 },   // 31 secs
  { id: '1208519639911637033', interval: 601000 }   // 10 mins 1 sec
];

const message = '**BIDDING HUGE DILO/CAN CA$H   \n24.98KG/AGE_36\nMAX 59.73KG/AGE_100\n\nSELLING:\nHUGE TABBY\n39.98KG/AGE_69\n16.61KG/AGE_20\nFOR RAC OFFERS**';

const channelState = new Map();

async function loadState() {
  let saved = {};
  try {
    const data = await fs.readFile(STATE_FILE, 'utf8');
    saved = JSON.parse(data);
    console.log('📁 Loaded state from file');
  } catch {
    console.log('📝 No saved state found, starting fresh...');
  }

  // Initialize state for all channels (preserves existing ones and adds new)
  channelConfigs.forEach(cfg => {
    const s = saved[cfg.id] || {};
    channelState.set(cfg.id, {
      lastBotMessageTime: s.lastBotMessageTime || 0,
      lastChannelActivity: s.lastChannelActivity || 0,
      pendingMessage: s.pendingMessage || false,
      intervalId: null
    });
  });
}

async function saveState() {
  try {
    const out = {};
    channelState.forEach((s, id) => {
      out[id] = {
        lastBotMessageTime: s.lastBotMessageTime,
        lastChannelActivity: s.lastChannelActivity,
        pendingMessage: s.pendingMessage
      };
    });
    await fs.writeFile(STATE_FILE, JSON.stringify(out, null, 2));
    console.log('💾 State saved');
  } catch (err) {
    console.error('❌ Saving error:', err.message);
  }
}

function startAutoSave() {
  setInterval(saveState, 30000);
  console.log('🔄 Auto‑save every 30s enabled');
}

async function hasNewActivitySinceLastMessage(channelId) {
  try {
    let chan = client.channels.cache.get(channelId);
    if (!chan) chan = await client.channels.fetch(channelId);
    if (!chan) return true;

    const state = channelState.get(channelId);
    const cached = chan.messages.cache;
    if (cached.size === 0) await chan.messages.fetch({ limit: 1 }).catch(() => {});
    const msgs = chan.messages.cache;
    return msgs.some(m => m.createdTimestamp > state.lastBotMessageTime && m.author.id !== client.user.id);
  } catch {
    return true;
  }
}

async function sendMessageToChannel(channelId) {
  const state = channelState.get(channelId);
  try {
    let chan = client.channels.cache.get(channelId);
    if (!chan) chan = await client.channels.fetch(channelId);
    if (!chan) return;

    const jitter = Math.floor(Math.random() * 5000) + 1000; // 1–6 seconds
    await new Promise(r => setTimeout(r, jitter));

    await chan.send(message);
    state.lastBotMessageTime = Date.now();
    state.pendingMessage = false;
  } catch (err) {
    console.error(`❌ Error sending to ${channelId}:`, err);
  }
}

async function tryToSendMessage(channelId) {
  const state = channelState.get(channelId);
  if (!state || state.pendingMessage) return;
  try {
    const activity = await hasNewActivitySinceLastMessage(channelId);
    if (activity) {
      await sendMessageToChannel(channelId);
    } else {
      state.pendingMessage = true;
    }
  } catch {
    setTimeout(() => {
      const s = channelState.get(channelId);
      if (s) s.pendingMessage = false;
    }, 30000);
  }
}

client.on('messageCreate', msg => {
  if (msg.author.id === client.user.id) return;
  const s = channelState.get(msg.channel.id);
  if (s && s.pendingMessage) {
    setTimeout(() => sendMessageToChannel(msg.channel.id), 2000);
  }
});

client.on('ready', async () => {
  console.log(`${client.user.username} is ready`);
  await loadState();
  startAutoSave();
  await new Promise(r => setTimeout(r, 2000));

  channelConfigs.forEach(cfg => {
    const delay = Math.floor(Math.random() * 10000);
    setTimeout(() => {
      const iid = setInterval(() => tryToSendMessage(cfg.id), cfg.interval);
      const st = channelState.get(cfg.id);
      if (st) st.intervalId = iid;
    }, delay);
  });
});

process.on('SIGINT', async () => {
  await saveState();
  channelState.forEach((s) => {
    if (s.intervalId) clearInterval(s.intervalId);
  });
  client.destroy();
  process.exit(0);
});

client.login(process.env.DISCORD_TOKEN);
