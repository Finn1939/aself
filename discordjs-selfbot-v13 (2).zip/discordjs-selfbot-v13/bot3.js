const { Client } = require('./src/index');
const fs = require('fs').promises;
const path = require('path');

const client = new Client();
const STATE_FILE = path.join(__dirname, 'bot3_state.json');

// ✅ Updated with new channel
const channelConfigs = [
  { id: '1385899507572670555', interval: 120000 },
  { id: '1389478173363929189', interval: 120000 },
  { id: '1389144837114302495', interval: 120000 },
  { id: '1208519639911637033', interval: 120000 },
  { id: '1369721387987505203', interval: 61000 } // ✅ NEW CHANNEL 1 min 1 sec
];

// ✅ New message
const message = `TRADING FOR PETS / FOR §@LE
HUGE <:kitsune:1399625322537943050> - 13.10KG, 46yo
HUGE DILO - 24.98kg, 36yo
<:dragonfly:1373885864341409842> 1 RAINBOW DRAGONFLY
🦖 1 MEGA T-REX 
🌠 1 ASCENDED STARFISH
🦉 2 MEGA OWLS (COOKED and BLOOD)
<:kitsune:1399625322537943050>  HUGE KITSUNE <a:Rarrow:1318955730497179768> 13.10kg, 46yo
TITANIC TRICERATOPS<a:Rarrow:1318955730497179768> 36.6kg, 36yo
TITANIC PARASAU...PHUS <a:Rarrow:1318955730497179768> 22.57kg, 24yo
<:kitsune:1399625322537943050> 2 - KITSUNE (normal sized)
<:raccoon:1373885770774876224>6 -  RACCOON
<:Butterfly:1385703537077653524> 4 - BUTTERFLY
<:DiscoBee:1381293773853818962>  2 - DISCO BEE
🦖 3 - TREX/SPINO
<:dragonfly:1373885864341409842> 6 - DRAGONFLY (1 Rainbow)
<:MimicOctopus:1388563665141370942> 2 - MIMIC OCTOPUS
<:QueenBee:1379733159591018567> 2 - QUEEN BEE (1 SHINY)
Lf: <:raccoon:1373885770774876224> <:DiscoBee:1381293773853818962> <:Butterfly:1385703537077653524><:dragonfly:1373885864341409842> <:MimicOctopus:1388563665141370942> <:kitsune:1399625322537943050> HUGE TABBY 🐱`;

const channelState = new Map();

async function loadState() {
  try {
    const data = await fs.readFile(STATE_FILE, 'utf8');
    const saved = JSON.parse(data);
    console.log('📁 Loaded state from file');
    channelConfigs.forEach(cfg => {
      const s = saved[cfg.id] || {};
      channelState.set(cfg.id, {
        lastBotMessageTime: s.lastBotMessageTime || 0,
        lastChannelActivity: s.lastChannelActivity || 0,
        pendingMessage: s.pendingMessage || false,
        intervalId: null
      });
    });
  } catch {
    console.log('📝 No saved state found, starting fresh...');
    channelConfigs.forEach(cfg => {
      channelState.set(cfg.id, {
        lastBotMessageTime: 0,
        lastChannelActivity: 0,
        pendingMessage: false,
        intervalId: null
      });
    });
  }
}

async function saveState() {
  try {
    const out = {};
    channelState.forEach((s, id) => {
      out[id] = {
        lastBotMessageTime: s.lastBotMessageTime,
        lastChannelActivity: s.lastChannelActivity,
        pendingMessage: s.pendingMessage
      };
    });
    await fs.writeFile(STATE_FILE, JSON.stringify(out, null, 2));
    console.log('💾 State saved');
  } catch (err) {
    console.error('❌ Saving error:', err.message);
  }
}

function startAutoSave() {
  setInterval(saveState, 30000);
  console.log('🔄 Auto‑save every 30s enabled');
}

async function hasNewActivitySinceLastMessage(channelId) {
  try {
    let chan = client.channels.cache.get(channelId);
    if (!chan) {
      console.log(`⚠️ Channel ${channelId} not cached; fetching...`);
      chan = await client.channels.fetch(channelId);
    }
    if (!chan) return true;
    const state = channelState.get(channelId);
    console.log(`🔍 Checking activity in ${channelId}...`);
    const cached = chan.messages.cache;
    if (cached.size === 0) {
      console.log(`📥 No cached messages; fetch recent...`);
      await chan.messages.fetch({ limit: 10, cache: true }).catch(() => {});
    }
    const msgs = chan.messages.cache;
    const recentUserMessages = msgs.filter(m =>
      m.createdTimestamp > state.lastBotMessageTime &&
      m.author.id !== client.user.id
    );

    console.log(`📊 ${recentUserMessages.length} new user message(s) in ${channelId}`);

    return recentUserMessages.length >= 6; // ✅ requires 6+ new messages
  } catch (err) {
    console.error(`❌ Error checking activity:`, err);
    return true;
  }
}

async function sendMessageToChannel(channelId) {
  const state = channelState.get(channelId);
  const start = Date.now();
  try {
    console.log(`🔍 Looking up channel ${channelId}...`);
    let chan = client.channels.cache.get(channelId);
    if (!chan) {
      console.log(`📥 Not in cache; fetching channel...`);
      chan = await client.channels.fetch(channelId);
    }
    if (!chan) {
      console.error(`❌ Channel ${channelId} unavailable`);
      return;
    }
    console.log(`📤 Sending message to ${channelId}...`);
    await chan.send(message);
    state.lastBotMessageTime = Date.now();
    state.pendingMessage = false;
    const dur = Date.now() - start;
    if (dur > 10000) console.warn(`⚠️ Send took ${dur}ms`);
    console.log(`✅ Message sent to ${channelId}`);
  } catch (err) {
    console.error(`❌ Error sending to ${channelId}:`, err);
    throw err;
  }
}

async function tryToSendMessage(channelId) {
  const state = channelState.get(channelId);
  if (!state || state.pendingMessage) return;
  try {
    console.log(`🕒 Timer triggered for ${channelId}...`);
    const activity = await hasNewActivitySinceLastMessage(channelId);
    if (activity) {
      console.log(`🟢 Activity found; sending message...`);
      await sendMessageToChannel(channelId);
    } else {
      console.log(`🟡 No recent activity; marking pending`);
      state.pendingMessage = true;
    }
  } catch (err) {
    console.error(`❌ tryToSendMessage failed for ${channelId}:`, err);
    setTimeout(() => {
      const s = channelState.get(channelId);
      if (s) s.pendingMessage = false;
    }, 30000);
  }
}

client.on('messageCreate', msg => {
  if (msg.author.id === client.user.id) return;
  const s = channelState.get(msg.channel.id);
  if (s && s.pendingMessage) {
    console.log(`🔔 Found pending message state in ${msg.channel.id}`);
    setTimeout(async () => {
      try {
        await sendMessageToChannel(msg.channel.id);
      } catch (err) {
        console.error(`❌ Error sending pending:`, err);
      }
    }, 2000);
  }
});

client.on('ready', async () => {
  console.log(`${client.user.username} is ready (ID: ${client.user.id})`);
  console.log(`📌 Joined ${client.guilds.cache.size} guild(s)`);
  await loadState();
  startAutoSave();
  await new Promise(r => setTimeout(r, 2000));

  let count = 0;

  channelConfigs.forEach(cfg => {
    const chan = client.channels.cache.get(cfg.id);
    const delay = Math.floor(Math.random() * 10000); // 0–10s delay
    setTimeout(() => {
      const iid = setInterval(() => tryToSendMessage(cfg.id), cfg.interval);
      const st = channelState.get(cfg.id);
      if (st) st.intervalId = iid;
      console.log(`⏱ Interval set for ${cfg.id} every ${cfg.interval}ms (initial delay: ${delay}ms)`);
    }, delay);
    count++;
  });

  console.log(`🎯 Setup done—actively monitoring ${count} channels`);
});

process.on('unhandledRejection', (r, p) => {
  console.error('Unhandled Rejection at:', p, 'reason:', r);
});

process.on('SIGINT', async () => {
  console.log('\n🛑 Shutting down...');
  await saveState();
  channelState.forEach((s, id) => {
    if (s.intervalId) clearInterval(s.intervalId);
    console.log(`Cleared interval for ${id}`);
  });
  client.destroy();
  process.exit(0);
});

client.login(process.env.DISCORD3_TOKEN);
